#include <float.h>

float scalanative_float_flt_min() { return FLT_MIN; }

double scalanative_float_dbl_min() { return DBL_MIN; }

float scalanative_float_flt_max() { return FLT_MAX; }

double scalanative_float_dbl_max() { return DBL_MAX; }

float scalanative_float_flt_epsilon() { return FLT_EPSILON; }

float scalanative_float_dbl_epsilon() { return DBL_EPSILON; }

int scalanative_float_flt_rounds() { return FLT_ROUNDS; }

int scalanative_float_flt_radix() { return FLT_RADIX; }

int scalanative_float_flt_mant_dig() { return FLT_MANT_DIG; }

int scalanative_float_dbl_mant_dig() { return DBL_MANT_DIG; }

int scalanative_float_flt_dig() { return FLT_DIG; }

int scalanative_float_dbl_dig() { return DBL_DIG; }

int scalanative_float_flt_min_exp() { return FLT_MIN_EXP; }

int scalanative_float_dbl_min_exp() { return DBL_MIN_EXP; }

int scalanative_float_flt_min_10_exp() { return FLT_MIN_10_EXP; }

int scalanative_float_dbl_min_10_exp() { return DBL_MIN_10_EXP; }

int scalanative_float_flt_max_exp() { return FLT_MAX_EXP; }

int scalanative_float_dbl_max_exp() { return DBL_MAX_EXP; }

int scalanative_float_flt_max_10_exp() { return FLT_MAX_10_EXP; }

int scalanative_float_dbl_max_10_exp() { return DBL_MAX_10_EXP; }
