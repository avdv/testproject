#include <stdlib.h>

int scalanative_exit_success() { return EXIT_SUCCESS; }

int scalanative_exit_failure() { return EXIT_FAILURE; }

int scalanative_rand_max() { return RAND_MAX; }
