#include <stddef.h>

// Macros
void *scalanative_clib_null() { return NULL; }
