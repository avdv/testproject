#if defined(_WIN32)
#ifndef WIN_FREQ_H
#define WIN_FREQ_H

int winFreqQuadPart(int *quad);

#endif // WIN_FREQ_H
#endif
