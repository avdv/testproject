#ifndef IMMIX_LOG_H
#define IMMIX_LOG_H

#ifndef DEBUG_ASSERT

#ifndef NDEBUG
#define NDEBUG
#endif // NDEBUG

#endif // DEBUG_ASSERT

#include <assert.h>
#include <inttypes.h>

// #define DEBUG_PRINT

#endif // IMMIX_LOG_H
