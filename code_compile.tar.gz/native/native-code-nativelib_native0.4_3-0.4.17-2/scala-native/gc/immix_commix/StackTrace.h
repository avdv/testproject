#ifndef IMMIX_STACKTRACE_H
#define IMMIX_STACKTRACE_H

#include "../../platform/unwind.h"

void StackTrace_PrintStackTrace();

#endif // IMMIX_STACKTRACE_H
