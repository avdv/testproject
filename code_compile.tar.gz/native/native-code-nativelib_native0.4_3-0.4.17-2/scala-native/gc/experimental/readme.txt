This directory is here to support developer experimental garbage collectors.
Put all the code in this directory and implement the methods required
in nativelib scala.scalanative.runtime.GC.scala and set GC.experimental
in the build.
