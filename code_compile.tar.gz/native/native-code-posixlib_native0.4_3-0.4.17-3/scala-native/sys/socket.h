#ifndef __SYS_SOCKET_H
#define __SYS_SOCKET_H

typedef unsigned short scalanative_sa_family_t;

#endif // __SYS_SOCKET_H
