
#define PSEMNAMLEN 31

